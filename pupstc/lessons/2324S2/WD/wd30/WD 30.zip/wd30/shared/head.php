<?php
include "shared/connect.php";
include "shared/string_functions.php";
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Xtra Blog</title>
  <link rel="stylesheet" href="fontawesome/css/all.min.css"> <!-- https://fontawesome.com/ -->
  <link href="https://fonts.googleapis.com/css2?family=Source+Sans+Pro&display=swap" rel="stylesheet">
  <!-- https://fonts.google.com/ -->
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <link href="css/templatemo-xtra-blog.css" rel="stylesheet">
</head>