<?php
function join_string($str1, $str2, $str_join)
{
  return $str1 . $str_join . $str2;
}
?>